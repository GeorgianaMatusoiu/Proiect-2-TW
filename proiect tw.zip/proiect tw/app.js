
const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/contact', (req, res) => {
    res.sendFile(path.join(__dirname, 'contact.html'));
});
app.post('/contact', (req, res) => {
    const { nume, prenume, email, data, bgColor, ciocolata, frisca, fistic, vanilie, altul, messageType, comentari } = req.body;

    const formData = {
        nume,
        prenume,
        email,
        data,
        bgColor,
        ciocolata,
        frisca,
        fistic,
        vanilie,
        altul,
        messageType,
        comentari
    };


    const filePath = path.join(__dirname, 'form-data.json');

    const dirPath = path.dirname(filePath);
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
    }

    fs.readFile(filePath, 'utf8', (err, data) => {
        let jsonData = [];
        if (!err && data) {
            jsonData = JSON.parse(data);
        }
        jsonData.push(formData);
        fs.writeFile(filePath, JSON.stringify(jsonData, null, 2), (err) => {
            if (err) {
                console.error('Error writing file:', err);
                return res.status(500).send('Error writing file');
            }
            res.send('Datele au fost salvate cu succes');
        });
    });
});
//pagina de eroare
app.use((req, res, next) => {
    res.status(404).send("404 - Pagina nu a fost găsită!");
  });

app.listen(3000, () => {
    console.log('Serverul nostru rulează pe portul 3000');
});
