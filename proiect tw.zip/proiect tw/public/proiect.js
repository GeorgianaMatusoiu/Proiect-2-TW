let cupcake = document.querySelector('.cupcake');
cupcake.addEventListener('mouseover', function() 
{
    this.style.boxShadow = '0 0 7px rgba(20, 20, 20, 15)';
    this.style.width = '7%';  
    this.style.height = '6%';
});
cupcake.addEventListener('mouseout', function()
{
    this.style.boxShadow = 'none';
});
var elementeRetete = document.querySelectorAll('.recipe');
elementeRetete.forEach(function(element) 
{
    element.style.border = "1px solid #ddd"; 
    element.style.borderRadius = "4px"; 
    element.style.padding = "4px"; 
    element.style.width = "356px"; 
});

var titlu = document.getElementById("nume");
titlu.textContent = "RETETE SIMPLE DE DULCIURI FACUTE ÎN CASA";
var elementeNav = document.querySelectorAll(".nav-link");
elementeNav.forEach(function(element) 
{
    element.style.color = "violet";
});
var imagini = document.querySelectorAll("img");
imagini.forEach(function(img) 
{
    img.style.border = "1px solid blue";
});
function adaugaParagraf()
{
    var paragrafNou = document.createElement("p");
    paragrafNou.textContent = "Această rețea oferă opțiunea rapidă și delicioasă pentru a satisface pofta de dulce în orice moment al zilei.";
    var secțiune = document.querySelector(".recipe-info");
    secțiune.appendChild(paragrafNou);
}

function stergeParagraf() 
{
    var secțiune = document.querySelector(".recipe-info");
    var paragrafUltim = secțiune.lastElementChild;
    secțiune.removeChild(paragrafUltim);
}
var titlu = document.getElementById("nume");
titlu.addEventListener('mouseenter', function() 
{
    this.style.color = 'blue'; 
});
titlu.addEventListener('mouseleave', function() 
{
    this.style.color = ''; 
});
var elementeNav = document.querySelectorAll(".nav-link");

var bodyElement = document.body;
        bodyElement.addEventListener('keydown', function(event) 
        {
            if (event.key === 'm') 
            {
                bodyElement.style.backgroundColor = 'rgb(234, 127, 170)';
            }
        });
        bodyElement.addEventListener('keyup', function(event)
         {
            if (event.key === 'm') 
            {
                bodyElement.style.backgroundColor = 'pink';
            }
        });


var imaginiRetete = document.querySelectorAll(".recipes-list img");
imaginiRetete.forEach(function(img) 
{
    img.style.borderRadius = "24px";
});
var textErou = document.querySelector(".hero-text");
textErou.style.fontFamily = "Arial, sans-serif";
textErou.style.color = "white";
textErou.style.fontWeight = "bold";
var paragrafe = document.querySelectorAll("p");
paragrafe.forEach(function(paragraf) {
    paragraf.style.backgroundColor = "rgb(234, 127, 170)";
    paragraf.style.fontSize = "16px"; 
});

window.onload = function(){
  
     const bgColor=document.getElementById("bgColor");
     if(!localStorage.getItem("bgColor"))
      {
        localStorage.setItem("bgColor", bgColor.value);
        document.body.style.backgroundColor=bgColor.value;
      }
      else
      {
        document.body.style.backgroundColor=localStorage.getItem("bgColor")
      }
      bgColor.onchange=function(){
        localStorage.setItem("bgColor", bgColor.value);
        document.body.style.backgroundColor=bgColor.value;
      }
  
  }
  
  function myFunction() {
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("myBtn");
  
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "Citește mai puțin";
      moreText.style.display = "none";
    } else {
      dots.style.display = "none";
      btnText.innerHTML = "Cițește mai mult";
      moreText.style.display = "inline";

    }
}
    
    document.addEventListener('DOMContentLoaded', function() 
    {
        const ratings = document.querySelectorAll('.rating');
        
        ratings.forEach(rating => {
          const stars = rating.querySelectorAll('.star');
          const initialRating = rating.getAttribute('data-rating');
      
          setRating(stars, initialRating);
      
          stars.forEach(star => {
            star.addEventListener('click', () => {
              const ratingValue = star.getAttribute('data-value');
              setRating(stars, ratingValue);
            });
          });
        });
      
        function setRating(stars, rating) {
          stars.forEach(star => {
            if (star.getAttribute('data-value') <= rating) {
              star.classList.remove('inactive');
            } else {
              star.classList.add('inactive');
            }
          });
        }
      });
      

let recipeImages = document.querySelectorAll(".recipe-item img");
recipeImages.forEach(function(image) 
{
  image.addEventListener("mouseenter", function(event) 
  {
    event.target.classList.add("hovered");
  });
  image.addEventListener("mouseleave", function(event) 
  {
    event.target.classList.remove("hovered");
  });
});

function register() 
{
  var nume = document.getElementById('nume').value;
  var prenume = document.getElementById('prenume').value;
  var email = document.getElementById('email').value;
  var username = document.getElementById('username').value;
  var password = document.getElementById('password').value;
  var userData = {
      nume: nume,
      prenume: prenume,
      email: email,
      username: username,
      password: password
  };
  localStorage.setItem('userData', JSON.stringify(userData));
  alert('Cont creat cu succes!');
  window.location.href = "login.html"; 
  return false;
}

function login() 
{
  var username = document.getElementById('username').value;
  var password = document.getElementById('password').value;
  var savedUserData = localStorage.getItem('userData');
  if (savedUserData) {
      savedUserData = JSON.parse(savedUserData);
      if (username === savedUserData.username && password === savedUserData.password) {
          localStorage.setItem('isLoggedIn', true);
          alert('Autentificare reușită!');
          window.location.href = "proiect2.html";
          return false;
      }
  }
  alert('Contul nu există! Creează un cont ');
   window.location.href = "register.html";
  return false;
}
function drawClock() 
{
  const canvas = document.getElementById('analogClock');
  const ctx = canvas.getContext('2d');
  const radius = canvas.height / 2;
  ctx.translate(radius, radius);
  const innerRadius = radius * 0.9;
  setInterval(() => {
      drawFace(ctx, innerRadius);
      drawNumbers(ctx, innerRadius);
      drawTime(ctx, innerRadius);
  }, 1000);
}

function getRandomColor()
{
const letters = "0123456789ABCDEF";
let color = "#";
for (let i = 0; i < 6; i++) 
  {
  color += letters[Math.floor(Math.random() * 16)];
}
return color;
}

function changeBackgroundColor() 
{
const color = getRandomColor();
document.body.style.backgroundColor = color;
}


function drawFace(ctx, radius) 
{
let grad;
ctx.beginPath();
ctx.arc(0, 0, radius, 0, 2 * Math.PI);
ctx.fillStyle = getRandomColor(); 
ctx.fill();

grad = ctx.createRadialGradient(0, 0, radius * 0.95, 0, 0, radius * 1.05);
grad.addColorStop(0, '#333');
grad.addColorStop(0.5, 'pink');
grad.addColorStop(1, '#333');
ctx.strokeStyle = grad;
ctx.lineWidth = radius * 0.1;
ctx.stroke();

ctx.beginPath();
ctx.arc(0, 0, radius * 0.1, 0, 2 * Math.PI);
ctx.fillStyle = '#333';
ctx.fill();
}
function getRandomColor() {
const letters = "0123456789ABCDEF";
let color = "#";
for (let i = 0; i < 6; i++) {
  color += letters[Math.floor(Math.random() * 16)];
}
return color;
}

function changeClockColor() 
{
const canvas = document.getElementById('analogClock');
const ctx = canvas.getContext('2d');
const radius = canvas.height / 2;
drawFace(ctx, radius);
}

setInterval(changeClockColor, 3000);

function drawNumbers(ctx, radius) 
{
  let ang;
  let num;
  ctx.font = `${radius * 0.15}px arial`;
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'center';
  for (num = 1; num < 13; num++) {
      ang = num * Math.PI / 6;
      ctx.rotate(ang);
      ctx.translate(0, -radius * 0.85);
      ctx.rotate(-ang);
      ctx.fillText(num.toString(), 0, 0);
      ctx.rotate(ang);
      ctx.translate(0, radius * 0.85);
      ctx.rotate(-ang);
  }
}

function drawTime(ctx, radius) {
  const now = new Date();
  let hour = now.getHours();
  let minute = now.getMinutes();
  let second = now.getSeconds();
  hour = hour % 12;
  hour = (hour * Math.PI / 6) +
         (minute * Math.PI / (6 * 60)) +
         (second * Math.PI / (360 * 60));
  drawHand(ctx, hour, radius * 0.5, radius * 0.07);
  minute = (minute * Math.PI / 30) + (second * Math.PI / (30 * 60));
  drawHand(ctx, minute, radius * 0.8, radius * 0.07);
  second = (second * Math.PI / 30);
  drawHand(ctx, second, radius * 0.9, radius * 0.02, 'red');
}

function drawHand(ctx, pos, length, width, color = '#333') 
{
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.lineCap = 'round';
  ctx.strokeStyle = color;
  ctx.moveTo(0, 0);
  ctx.rotate(pos);
  ctx.lineTo(0, -length);
  ctx.stroke();
  ctx.rotate(-pos);
}
drawClock();

var element = document.getElementById("nume");
var style = window.getComputedStyle(element);
var color = style.getPropertyValue("color");
document.getElementById("culoare-text").innerText = "Culoarea titlului este: " + color;

const stars = document.querySelectorAll('.rating .star');
stars.forEach(star => {
  star.addEventListener('click', function(event) {
    event.preventDefault();
    event.stopPropagation();
    const ratingValue = parseInt(this.getAttribute('data-value'));
    updateRatingUI(this.parentElement, ratingValue);
  });
});
function updateRatingUI(ratingContainer, ratingValue) {
  const stars = ratingContainer.querySelectorAll('.star');
  stars.forEach((star, index) => {
    if (index < ratingValue) {
      star.classList.add('selected');
    } else {
      star.classList.remove('selected');
    }
  });
}

const navLinks = document.querySelectorAll('.nav-link');
const navLinksArray = Array.from(navLinks);
navLinksArray.forEach(link => {
    link.style.color = 'purple'; 
});

document.addEventListener('DOMContentLoaded', function() 
{
  const paragraph = document.getElementById('text-content');
  const upperCaseText = paragraph.textContent.toUpperCase();
  paragraph.textContent = upperCaseText;
});


