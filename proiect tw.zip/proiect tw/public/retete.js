document.addEventListener('DOMContentLoaded', function() 
        {
            fetch('retete.json')
                .then(response => response.json())
                .then(data => {
                    const recipesContainer = document.getElementById('recipes');
                    data.forEach(recipe => {
                        const recipeDiv = document.createElement('div');
                        recipeDiv.innerHTML = `
                            <h2>${recipe.nume}</h2>
                            <p>Ingrediente: ${recipe.ingrediente}</p>
                            <p>Mod de preparare: ${recipe.preparare}</p>
                            <p>Timpul necesar: ${recipe.timp}</p>
                            <hr>
                        `;
                        recipesContainer.appendChild(recipeDiv);
                    });
                })
                .catch(error => console.error('Eroare la preluarea retetelor:', error));
        });